//
//  Arvore.swift
//  Arvore234
//
//  Created by Anne Kariny Silva Freitas on 24/11/18.
//  Copyright © 2018 Anne Kariny Silva Freitas. All rights reserved.
//

import Foundation


class Tree {
    var root: Node?
    
    func deleteTree() {
        if let root = self.root {
            root.deleteData()
            root.left?.deleteData()
            root.middle1?.deleteData()
            root.middle2?.deleteData()
            root.right?.deleteData()
        }
    }
    
    // Encontra o nó contendo o menor valor de uma sub-árvore
    func findMin(root: Node) -> Node? {
        if root.isLeaf {
            return root
        }
        
        var minNode = root.left
        while (minNode?.left != nil) {
            minNode = minNode?.left
        }
        
        return minNode
    }
    
    // INSERÇÃO
    @discardableResult
    func add(key: Int) -> Bool {
        if root == nil {
            root = Node(valueForA: key)
            return true
        }
        
        var nPtr = root //.copy()
        var parent = root //.copy()
        
        while nPtr != nil {
            // Verifica se há duplicados
            if let nPtr = nPtr, nPtr.containsKey(key) { return false }
            
            // CASO 1 - Se seus 3 nós se dividirem
            if nPtr?.isFull ?? false {
                
                // CASO 1a = O pai do nó tem uma chave
                if let parent = parent, parent.count == 1 {
                    if let nPtr = nPtr, let parentA = parent.a, let parentB = nPtr.b, parentA < parentB {
                        parent.b = nPtr.b
                        parent.middle1 = Node(valueForA: nPtr.a, leftChildOfA: nPtr.left, rightChildOfA: nPtr.middle1)
                        parent.middle2 = Node(valueForA: nPtr.c, leftChildOfA: nPtr.middle2, rightChildOfA: nPtr.right)
                    } else if let nPtr = nPtr {
                        parent.b = parent.a
                        parent.middle2 = parent.middle1
                        parent.a = nPtr.b
                        parent.left = Node(valueForA: nPtr.a, leftChildOfA: nPtr.left, rightChildOfA: nPtr.middle1)
                        parent.middle1 = Node(valueForA: nPtr.c, leftChildOfA: nPtr.middle2, rightChildOfA: nPtr.right)
                    }
                    
                    nPtr = nil
                    
                    if let parentA = parent.a, key < parentA {
                        nPtr = parent.left
                    } else if let parentB = parent.b, key < parentB {
                        nPtr = parent.middle1
                    } else if let parentB = parent.b, key > parentB {
                        nPtr = parent.middle2
                    } else {
                        return false // Duplicado
                    }
                } // Fim caso 1a
                    
                    // CASO 1b - Se o pai do nó tem duas chaves
                else if let parent = parent, parent.count == 2 {
                    if let nPtr = nPtr, let parentB = parent.b, let nPtrB = nPtr.b, parentB < nPtrB {
                        parent.c = nPtr.b
                        parent.middle2 = Node(valueForA: nPtr.a, leftChildOfA: nPtr.left, rightChildOfA: nPtr.middle1)
                        parent.right = Node(valueForA: nPtr.c, leftChildOfA: nPtr.middle2, rightChildOfA: nPtr.right)
                    } else if let nPtr = nPtr, let parentA = parent.a, let nPtrB = nPtr.b, parentA < nPtrB {
                        parent.c = parent.b
                        parent.right = parent.middle2
                        parent.b = nPtr.b
                        parent.middle1 = Node(valueForA: nPtr.a, leftChildOfA: nPtr.left, rightChildOfA: nPtr.middle1)
                        parent.middle2 = Node(valueForA: nPtr.c, leftChildOfA: nPtr.middle2, rightChildOfA: nPtr.right)
                    } else {
                        parent.c = parent.b
                        parent.right = parent.middle2
                        parent.b = parent.a
                        parent.middle2 = parent.middle1
                        parent.a = nPtr?.b
                        parent.left = Node(valueForA: nPtr?.a, leftChildOfA: nPtr?.left, rightChildOfA: nPtr?.middle1)
                        parent.middle1 = Node(valueForA: nPtr?.c, leftChildOfA: nPtr?.middle2, rightChildOfA: nPtr?.right)
                    }
                    
                    nPtr = nil
                    
                    if let parentA = parent.a, key < parentA {
                        nPtr = parent.left
                    } else if let parentB = parent.b, key < parentB {
                        nPtr = parent.middle1
                    } else if let parentC = parent.c, key < parentC {
                        nPtr = parent.middle2
                    } else if let parentC = parent.c, key > parentC {
                        nPtr = parent.right
                    } else {
                        return false // Duplicado
                    }
                } // Fim caso 1b
                    
                    // CASO 1c - Se o pai do no tem 3 chaves
                else {
                    root = Node(valueForA: nPtr?.b)
                    root?.left = Node(valueForA: nPtr?.a, leftChildOfA: nPtr?.left, rightChildOfA: nPtr?.middle1)
                    root?.middle1 = Node(valueForA: nPtr?.c, leftChildOfA: nPtr?.middle2, rightChildOfA: nPtr?.right)
                    
                    nPtr = nil
                    parent = root
                    
                    if let root = root, let rootA = root.a, key < rootA {
                        nPtr = root.left
                    } else if let root = root, let rootA = root.a, key > rootA {
                        nPtr = root.middle1
                    } else {
                        return false // Duplicado
                    }
                } // Fim caso 1c
            } // Fim Caso 1
            
            // CASO 2 - é uma folha
            if let nPtr = nPtr, nPtr.isLeaf {
                // Caso 2a - Tem uma chave
                if nPtr.count == 1 {
                    if let nPtrA = nPtr.a, key > nPtrA {
                        nPtr.b = key
                        return true
                    } else if let nPrtA = nPtr.a, key < nPrtA {
                        nPtr.b = nPtr.a
                        nPtr.a = key
                        return true
                    }
                } // Fim caso 2a
                    
                    // Caso 2b - Tem duas chaves
                else if nPtr.count == 2 {
                    if let nPtrB = nPtr.b, key > nPtrB {
                        nPtr.c = key
                        return true
                    } else if let nPrtA = nPtr.a, key > nPrtA {
                        nPtr.c = nPtr.b
                        nPtr.b = key
                        return true
                    } else if let nPtrA = nPtr.a, key < nPtrA {
                        nPtr.c = nPtr.b
                        nPtr.b = nPtr.a
                        nPtr.a = key
                    }
                } // Fim do caso 2b
            } // Fim do Caso 2
                
                // CASO 3 - Não é uma folha
            else {
                parent = nPtr
                
                // Caso 3a - Tem 1 chave
                if nPtr?.count == 1 {
                    if let nPtrA = nPtr?.a, key < nPtrA {
                        nPtr = nPtr?.left
                    } else {
                        nPtr = nPtr?.middle1
                    }
                }
                    
                    // Caso 3b - Tem 2 chaves
                else if nPtr?.count == 2 {
                    if let nPtrA = nPtr?.a, key < nPtrA {
                        nPtr = nPtr?.left
                    } else if let nPtrB = nPtr?.b, key < nPtrB {
                        nPtr = nPtr?.middle1
                    } else {
                        nPtr = nPtr?.middle2
                    }
                }
                
            } // Fim do Caso 3
            
        } // Fim while
        
        // Nunca deve chegar aqui
        return false
    }
    
    // BUSCA
    func search(key: Int) -> Int? {
        guard let nPtr = root else { return nil }
        return nPtr.containsKey(key) ? key : search(key: key, in: nPtr)
    }
    
    private func search(key: Int, in node: Node) -> Int? {
        if node.containsKey(key) {
            return key
        } else {
            if let nodeC = node.c, let nodeRight = node.right, nodeC < key {
                return search(key: key, in: nodeRight)
            } else if let nodeB = node.b, let nodeMiddle2 = node.middle2, nodeB < key {
                return search(key: key, in: nodeMiddle2)
            } else if let nodeA = node.a, let nodeMiddle1 = node.middle1, nodeA < key  {
                return search(key: key, in: nodeMiddle1)
            } else if let nodeLeft = node.left {
                return search(key: key, in: nodeLeft)
            } else {
                return nil
            }
        }
    }
    
    // DELEÇÃO
    @discardableResult
    func delete(value: Int) -> Bool {
        guard let root = root else { return false }
        
        var nPtr: Node? = root
        var parent: Node? = root
        
        var item: Int? = nil
        var nItem: Node? = nil
        var key = value
        
        while nPtr != nil {
            
            // CASO 1: Se o valor está na raiz que tem apenas 1 valor e ambos os seus descendentes tem 1 valor
            if nPtr == root && nPtr?.count == 1 && nPtr?.left?.count == 1 && nPtr?.middle1?.count == 1 {
                
                // Coloca o nó da direita como C da raiz e atualiza RIGHT e MIDDLE 2
                let right = nPtr?.middle1
                nPtr?.c = right?.a
                nPtr?.right = right?.middle1
                nPtr?.middle2 = right?.left
                right?.deleteData()
                
                // Coloca o A antigo como B
                nPtr?.b = nPtr?.a
                
                // Coloca o nó da esquerda como A da raiz e atualiza LEFT e MIDDLE 1
                let left = nPtr?.left
                nPtr?.a = left?.a
                nPtr?.left = left?.left
                nPtr?.middle1 = left?.middle1
                left?.deleteData()
                
                parent = root
                nPtr = root
            } // FIM CASO 1
            
            // CASO 2: Transformações (Garantir que não ocorre em 2-node)
            // a) Transforma cada nó encontrado em um 3-node ou 4-node
            if nPtr?.count == 1 {
                
                // Apenas 1 valor no filho da esquerda
                if parent?.left == nPtr {
                    // Pai tem mais de 1 valor e M1 tem 1 valor, FUSAO!
                    if parent?.middle1?.count == 1 {
                        // Seta C, R e M2 do pai
                        parent?.middle1?.c = parent?.middle1?.a
                        parent?.middle1?.right = parent?.middle1?.middle1
                        parent?.middle1?.middle2 = parent?.middle1?.left
                        // Seta o B
                        parent?.middle1?.b = parent?.a
                        // Seta o A, L e M1
                        parent?.middle1?.a = nPtr?.a
                        parent?.middle1?.left = nPtr?.left
                        parent?.middle1?.middle1 = nPtr?.middle1
                        parent?.left?.deleteData()
                        
                        parent?.a = parent?.b
                        parent?.b = parent?.c
                        parent?.c = nil
                        
                        parent?.left = parent?.middle1
                        parent?.middle1 = parent?.middle2
                        parent?.middle2 = parent?.right
                        parent?.right = nil
                        
                        nPtr = parent?.left
                    }
                        
                        // Irmãos tem mais de 1 valor, pega emprestado
                    else if let parentMiddle1 = parent?.middle1, parentMiddle1.count >= 2 {
                        // Seta B e M2
                        nPtr?.b = parent?.a
                        nPtr?.middle2 = parent?.middle1?.left
                        
                        // Seta parent A
                        parent?.a = parent?.middle1?.a
                        
                        // Seta A, B, C do M1 e seus filhos
                        parent?.middle1?.a = parent?.middle1?.b
                        parent?.middle1?.b = parent?.middle1?.c
                        parent?.middle1?.c = nil
                        
                        parent?.middle1?.left = parent?.middle1?.middle1
                        parent?.middle1?.middle1 = parent?.middle1?.middle2
                        parent?.middle1?.middle2 = parent?.middle1?.right
                        parent?.middle1?.right = nil
                    }
                } // Final de 1 valor no filho da esquerda
                    
                    // Apenas 1 valor no filho MIDDLE 1
                else if parent?.middle1 == nPtr {
                    
                    // L e M2 tem apenas 1 valor, FUSAO do L e M1 L & M2
                    if parent?.left?.count == 1 && parent?.middle2?.count == 1 {
                        // Seta C, R e M2
                        nPtr?.c = nPtr?.a
                        nPtr?.right = nPtr?.middle1
                        nPtr?.middle2 = nPtr?.left
                        
                        // Seta B
                        nPtr?.b = parent?.a
                        
                        // Seta A, L e M1
                        nPtr?.a = parent?.left?.a
                        nPtr?.middle1 = parent?.left?.middle1
                        nPtr?.left = parent?.left?.left
                        
                        parent?.left?.deleteData()
                        
                        parent?.a = parent?.b
                        parent?.b = parent?.c
                        parent?.c = nil
                        parent?.left = parent?.middle1
                        parent?.middle1 = parent?.middle2
                        parent?.middle2 = parent?.right
                        parent?.right = nil
                    }
                        
                        // Pega emprestado do M2
                    else if let parentLeft = parent?.left, let parentMiddle2 = parent?.middle2, parentLeft.count < parentMiddle2.count {
                        // Seta B e M2
                        nPtr?.b = parent?.b
                        nPtr?.middle2 = parent?.middle2?.left
                        
                        // Seta o B do pai
                        parent?.b = parent?.middle2?.a
                        
                        // Seta M2 values and pointers
                        parent?.middle2?.a = parent?.middle2?.b
                        parent?.middle2?.b = parent?.middle2?.c
                        parent?.middle2?.c = nil
                        parent?.middle2?.left = parent?.middle2?.middle1
                        parent?.middle2?.middle1 = parent?.middle2?.middle2
                        parent?.middle2?.middle2 = parent?.middle2?.right
                        parent?.middle2?.right = nil
                    }
                        
                        // Pega emprestado do L
                    else {
                        // Seta B, M1 e M2
                        nPtr?.b = nPtr?.a
                        nPtr?.middle2 = nPtr?.middle1
                        nPtr?.middle1 = nPtr?.left
                        
                        // Seta A, A do pai e L
                        nPtr?.a = parent?.a
                        
                        if let parentLeft = parent?.left, let _ = parentLeft.c {
                            nPtr?.left = parent?.left?.right
                            parent?.a = parent?.left?.c
                            parent?.left?.c = nil
                            parent?.left?.right = nil
                        } else {
                            nPtr?.left = parent?.left?.middle2
                            parent?.a = parent?.left?.b
                            parent?.left?.b = nil
                            parent?.left?.middle2 = nil
                        }
                    }
                } // Fim 1 valor no MIDDLE 1
                    
                    // Apenas 1 valor no M2
                else if parent?.middle2 == nPtr {
                    
                    // M1 e R tem apenas 1 valor, FUSÃO do M2 e R
                    if parent?.middle1?.count == 1 && parent?.right?.count == 1 {
                        // Seta B
                        nPtr?.b = parent?.c
                        parent?.c = nil
                        
                        // Seta C, M2 e R
                        nPtr?.c = parent?.right?.a
                        nPtr?.middle2 = parent?.right?.left
                        nPtr?.right = parent?.right?.middle1
                        
                        parent?.right?.deleteData()
                        parent?.right = nil
                    }
                        
                        // Pega emprestado do R
                    else if let parentRight = parent?.right, let parrentMiddle1 = parent?.middle1, parentRight.count >=  parrentMiddle1.count {
                        // Seta B e M2
                        nPtr?.b = parent?.c
                        nPtr?.middle2 = parent?.right?.left
                        
                        // Seta parent C
                        parent?.c = parent?.right?.a
                        
                        // Seta R values and pointers
                        parent?.right?.a = parent?.right?.b
                        parent?.right?.b = parent?.right?.c
                        parent?.right?.c = nil
                        parent?.right?.left = parent?.right?.middle1
                        parent?.right?.middle1 = parent?.right?.middle2
                        parent?.right?.middle2 = parent?.right?.right
                        parent?.right?.right = nil
                    }
                        
                        // Pega emprestado do M1
                    else {
                        // Seta B, M1 e M2
                        nPtr?.b = nPtr?.a
                        nPtr?.middle2 = nPtr?.middle1
                        nPtr?.middle1 = nPtr?.left
                        
                        // Seta A, B do pai e L
                        nPtr?.a = parent?.b
                        if let parentMiddle1 = parent?.middle1, let _ = parentMiddle1.c {
                            nPtr?.left = parent?.middle1?.right
                            parent?.b = parent?.middle1?.c
                            parent?.middle1?.right = nil
                            parent?.middle1?.c = nil
                        } else {
                            nPtr?.left = parent?.middle1?.middle2
                            parent?.b = parent?.middle1?.b
                            parent?.middle1?.middle2 = nil
                            parent?.middle1?.b = nil
                        }
                    }
                    
                } // Fim 1 valor no M2
                    
                    // Apenas 1 valor no R
                else if parent?.right == nPtr {
                    // M2 tem 1 valor, FUSÃO M2 e R
                    if parent?.middle2?.count == 1 {
                        // Seta B
                        parent?.middle2?.b = parent?.c
                        parent?.c = nil
                        
                        // Seta C, M2 e R
                        parent?.middle2?.c = nPtr?.a
                        parent?.middle2?.middle2 = nPtr?.left
                        parent?.middle2?.right = nPtr?.middle1
                        
                        nPtr?.a = nil
                        nPtr?.left = nil
                        nPtr?.middle1 = nil
                        parent?.right?.deleteData()
                        
                        nPtr = parent?.middle2
                    }
                        
                        // Pega emprestado do M2
                    else if let parentMiddle2 = parent?.middle2, parentMiddle2.count >= 2 {
                        // Seta B, M1 e M2
                        nPtr?.b = nPtr?.a
                        nPtr?.middle2 = nPtr?.middle1
                        nPtr?.middle1 = nPtr?.left
                        
                        // Seta A, C do pai e L
                        nPtr?.a = parent?.c
                        if let parentMiddle2 = parent?.middle2, let _ = parentMiddle2.c {
                            nPtr?.left = parent?.middle2?.right
                            parent?.c = parent?.middle2?.c
                            parent?.middle2?.right = nil
                            parent?.middle2?.c = nil
                        } else {
                            nPtr?.left = parent?.middle2?.middle2
                            parent?.c = parent?.middle2?.b
                            parent?.middle2?.middle2 = nil
                            parent?.middle2?.c = nil
                        }
                    }
                    
                } // Fim de 1 chave no R
            } // Fim CASO 2 - Transformações
            
            // CASO 3: O Item não foi encontrado mas a chave está nesse nó, mas este nó não é uma folha
            if item == nil && (nPtr?.containsKey(key) ?? false) && !(nPtr?.isLeaf ?? false) {
                parent = nPtr
                nItem = nPtr      // Aponta para o nó onde a chave foi encontrada
                
                if nPtr?.c == key {
                    item = nPtr?.c
                    nPtr = nPtr?.right  // Vai para a direita do valor
                } else if nPtr?.b == key {
                    item = nPtr?.b
                    nPtr = nPtr?.middle2 // Vai para a direita do valor
                } else {
                    item = nPtr?.a
                    nPtr = nPtr?.middle1 // Vai para a direita do valor
                }
            } // Fim do CASO 3
                
                // CASO 4: Item encontrado e o nó contem o valor ou contém o valor e é uma folha, pega o sucessor do valor
            else if (item != nil && nPtr?.containsKey(key) ?? false) || ((nPtr?.containsKey(key) ?? false) && (nPtr?.isLeaf ?? false)) {
                
                while true {
                    if let nPtrUnwrapped = nPtr, nPtrUnwrapped.count >= 2 {
                        // valor é C
                        if key == nPtr?.c {
                            nPtr?.c = nil
                        }
                            
                            // valor é B
                        else if key == nPtr?.b {
                            nPtr?.b = nPtr?.c
                            nPtr?.c = nil
                        }
                            
                            // valor é A
                        else {
                            nPtr?.a = nPtr?.b
                            nPtr?.b = nPtr?.c
                            nPtr?.c = nil
                        }
                        return true
                    }
                        
                        // Chave está na direita
                    else if parent?.right == nPtr {
                        // M2 e R tem apenas 1 valor, FUSÃO
                        if parent?.middle2?.count == 1 && parent?.right?.count == 1 {
                            parent?.middle2?.b = parent?.c
                            parent?.middle2?.c = nPtr?.a
                            nPtr?.a = nil
                            parent?.right?.deleteData()
                            
                            parent?.right = nil
                            parent?.c = nil
                            nPtr = parent?.middle2
                        }
                            
                            // R tem 1 valor e M2 tem mais de 1 valor
                        else  {
                            // Pega emprestado do C do pai
                            nPtr?.b = nPtr?.a
                            nPtr?.a = parent?.c
                            
                            // Se houver um c no middle2, pega emprestado
                            if (parent?.middle2?.c) != nil {
                                parent?.c = parent?.middle2?.c
                                parent?.middle2?.c = nil
                            }
                                // C do pai pega emprestado do B do M2
                            else {
                                parent?.c = parent?.middle2?.b
                                parent?.middle2?.b = nil
                            }
                        }
                    }
                        
                        // O valor está no M2
                    else if parent?.middle2 == nPtr {
                        // M1, M2 e R tem 1 valor, FUSÃO M2 e R
                        if (parent?.middle1?.count == 1 && parent?.middle2?.count == 1 && parent?.c == nil) ||
                            (parent?.right != nil && parent?.middle1?.count == 1 && parent?.middle2?.count == 1 && parent?.right?.count == 1) {
                            
                            nPtr?.b = parent?.c
                            nPtr?.c = parent?.right?.a
                            parent?.right?.a = nil
                            parent?.right?.deleteData()
                            
                            parent?.right = nil
                            parent?.c = nil
                        }
                            
                            // M2 tem 1 chave e R tem mais chaves que M1
                        else if let parentRight = parent?.right, let parentMiddle1 = parent?.middle1, parentRight.count >= parentMiddle1.count {
                            
                            // Pega emprestado do C do pai
                            nPtr?.b = parent?.c
                            
                            // C do pai pega emprestado o A do R
                            parent?.c = parent?.right?.a
                            parent?.right?.a = parent?.right?.b
                            parent?.right?.b = parent?.right?.c
                            parent?.right?.c = nil
                        }
                            
                            // M2 tem 1 chave e M1 tem mais chaves que R
                        else {
                            // Pega emprestado do B do pai
                            nPtr?.b = nPtr?.a
                            nPtr?.a = parent?.b
                            
                            // B do pai pega emprestado C do M1
                            if (parent?.middle1?.c) != nil {
                                parent?.b = parent?.middle1?.c
                                parent?.middle1?.c = nil
                            }
                                
                                // B do pai pega emprestado o B do M1
                            else {
                                parent?.b = parent?.middle1?.b
                                parent?.middle1?.b = nil
                            }
                        }
                    }
                        
                        // Valor está no M1
                    else if parent?.middle1 == nPtr {
                        // L, M1, e M2 tem apenas 1 valor. FUSÃO de L e M1
                        if parent?.left?.count == 1 && parent?.middle1?.count == 1 && parent?.middle2?.count == 1 {
                            nPtr?.c = nPtr?.a
                            nPtr?.b = parent?.a
                            nPtr?.a = parent?.left?.a
                            parent?.left?.a = nil
                            parent?.left?.deleteData()
                            
                            parent?.a = parent?.b
                            parent?.b = parent?.c
                            parent?.left = parent?.middle1
                            parent?.middle1 = parent?.middle2
                            parent?.middle2 = parent?.right
                            parent?.right = nil
                        }
                            
                            // M1 tem 1 valor e M2 tem mais valores do que L
                        else if let parentLeft =  parent?.left, let parentMiddle2 = parent?.middle2, parentLeft.count < parentMiddle2.count {
                            // Pega emprestado do B do pai
                            nPtr?.b = parent?.b
                            
                            // B pega emprestado do A do M2
                            parent?.b = parent?.middle2?.a
                            parent?.middle2?.a = parent?.middle2?.b
                            parent?.middle2?.b = parent?.middle2?.c
                            parent?.middle2?.c = nil
                        }
                            
                            // M1 tem 1 valor e L tem mais chaves que M2
                        else {
                            // Pega emprestado do A do pai
                            nPtr?.b = nPtr?.a
                            nPtr?.a = parent?.a
                            
                            // A pega emprestado C do L
                            if (parent?.left?.c) != nil {
                                parent?.a = parent?.left?.c
                                parent?.left?.c = nil
                            }
                                
                                // A do pai pega emprestado B do L
                            else {
                                parent?.a = parent?.left?.b
                                parent?.left?.b = nil
                            }
                        }
                    }
                        
                        // Valor está no L
                    else {
                        // L e M1 tem apenas 1 valor, FUSÃO!
                        if parent?.left?.count == 1 && parent?.middle1?.count == 1 {
                            parent?.middle1?.c = parent?.middle1?.a
                            parent?.middle1?.b = parent?.a
                            parent?.middle1?.a = parent?.left?.a
                            parent?.left?.a = nil
                            parent?.left?.deleteData()
                            
                            parent?.a = parent?.b
                            parent?.b = parent?.c
                            parent?.left = parent?.middle1
                            parent?.middle1 = parent?.middle2
                            parent?.middle2 = parent?.right
                            parent?.right = nil
                            
                            nPtr = parent?.middle1
                        }
                            
                            // L tem 1 valor, pega emprestado do M1
                        else {
                            // Pega emprestado do A do pai
                            nPtr?.b = parent?.a
                            
                            // A do pai pega emprestado do A do M1
                            parent?.a = parent?.middle1?.a
                            parent?.middle1?.a = parent?.middle1?.b
                            parent?.middle1?.b = parent?.middle1?.c
                            parent?.middle1?.c = nil
                        }
                    }
                } // Fim while true
            } // FIM CASO 4
            
            // CASO 5: Item não encontrado, então continua procurando
            if item == nil {
                parent = nPtr
                if let nPtrC = nPtr?.c, key > nPtrC {
                    nPtr = nPtr?.right
                } else if let nPtrB = nPtr?.b, key > nPtrB {
                    nPtr = nPtr?.middle2
                } else if let nPtrA = nPtr?.a, key > nPtrA {
                    nPtr = nPtr?.middle1
                } else {
                    nPtr = nPtr?.left
                }
            }
                
                // Case: Item encontrado, procura pelo seu sucessor na árvore
            else {
                // A do nPtr é o sucessor
                if nPtr?.left == nil {
                    if nItem?.a == item {
                        nItem?.a = nPtr?.a
                    } else if nItem?.b == item {
                        nItem?.b = nPtr?.a
                    } else {
                        nItem?.c = nPtr?.a
                    }
                    
                    if let nPtrA = nPtr?.a {
                        key = nPtrA
                    }
                } else {
                    parent = nPtr
                    nPtr = nPtr?.left   // Vai para a esquerda da chave
                }
            }
        }
        
        return false
    }
    
    
    
    func display(node: Node) {
        if let left = node.left {
            print("LEFT")
            display(node: left)
        }
        
        if let aVal = node.a {
            print(" a: \(aVal) ")
        }
        
        if let m1 = node.middle1 {
            print("M1")
            display(node: m1)
        }
        
        if let bVal = node.b {
            print(" b: \(bVal) ")
        }
        
        if let m2 = node.middle2 {
            print("M2")
            display(node: m2)
        }
        
        if let cVal = node.c {
            print(" c: \(cVal) ")
        }
        
        if let right = node.right {
            print("RIGHT")
            display(node: right)
        }
    }
}
