//
//  ViewController.swift
//  Arvore234
//
//  Created by Anne Kariny Silva Freitas on 24/11/18.
//  Copyright © 2018 Anne Kariny Silva Freitas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let tree = Tree()
        tree.add(key: 5)
        tree.add(key: 1)
        tree.add(key: 10)
        tree.add(key: 20)
        tree.add(key: 30)
        tree.add(key: 50)
        tree.add(key: 100)
        tree.add(key: 200)
        tree.add(key: 250)
        tree.add(key: 500)
        tree.delete(value: 1)
        tree.display(node: tree.root!)
        
    }


}

