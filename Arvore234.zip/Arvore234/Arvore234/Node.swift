//
//  No.swift
//  Arvore234
//
//  Created by Anne Kariny Silva Freitas on 24/11/18.
//  Copyright © 2018 Anne Kariny Silva Freitas. All rights reserved.
//

import Foundation

class Node: Equatable {
    // Valores contidos no nó
    var a: Int?
    var b: Int?
    var c: Int?
    
    // Variáveis que apontam para outros nós (filhos deste nó)
    var left: Node?
    var middle1: Node?
    var middle2: Node?
    var right: Node?
    
    // Inicializa o no com 1 valor, os outros 2 valores ficam nulos, assim como os filhos
    init(valueForA: Int?) {
        a = valueForA
    }

    // Inicializa o nó com 1 valor e dois filhos (esquerdo e direito)
    init(valueForA: Int?, leftChildOfA: Node?, rightChildOfA: Node?) {
        a = valueForA
        left = leftChildOfA
        middle1 = rightChildOfA
    }
    
    // Inicializa um nó com todos os valores
    init(aVal: Int?, bVal: Int?, cVal: Int?, left: Node?, middle1: Node?, middle2: Node?, right: Node?) {
        a = aVal
        b = bVal
        c = cVal
        self.left = left
        self.middle1 = middle1
        self.middle2 = middle2
        self.right = right
    }
    
    // Se o nó possui todos os valores ocupados
    var isFull: Bool {
        return a ?? nil != nil && b ?? nil != nil && c ?? nil != nil
    }
    
    // Se todos os filhos são nulos, é uma folha
    var isLeaf: Bool {
        return left == nil && middle1 == nil && middle2 == nil && right == nil
    }
    
    // Tipo do nó: 2-no, 3-no ou 4-no
    var count: Int {
        if c != nil {
            return 3
        } else if b != nil {
            return 2
        } else {
            return 1
        }
    }
    
    func containsKey(_ key: Int) -> Bool {
        return key == a || key == b || key == c
    }
    
    func deleteData() {
        a = nil
        b = nil
        c = nil
    }
    
    func copy() -> Node {
        return Node(aVal: a, bVal: b, cVal: c, left: left, middle1: middle1, middle2: middle2, right: right)
    }
    
    static func == (lhs: Node, rhs: Node) -> Bool {
        return lhs.a == rhs.a && lhs.b == rhs.b && lhs.c == rhs.c
            && lhs.left == rhs.left && lhs.middle1 == rhs.middle1 && lhs.middle2 == lhs.middle2 && lhs.right == rhs.right
    }
}

